<template>
  <div>
    <my-nav />
    <nuxt />
  </div>
</template>

<script>
export default {}
</script>
