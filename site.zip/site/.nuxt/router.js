import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _21ca62b5 = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _2bf26945 = () => interopDefault(import('..\\pages\\articles.vue' /* webpackChunkName: "pages/articles" */))
const _3d38e39d = () => interopDefault(import('..\\pages\\articles\\index.vue' /* webpackChunkName: "pages/articles/index" */))
const _3d6d2a1b = () => interopDefault(import('..\\pages\\articles\\_tagId.vue' /* webpackChunkName: "pages/articles/_tagId" */))
const _7b14a764 = () => interopDefault(import('..\\pages\\redirect.vue' /* webpackChunkName: "pages/redirect" */))
const _84a7d95c = () => interopDefault(import('..\\pages\\search\\index.vue' /* webpackChunkName: "pages/search/index" */))
const _d7a2bea8 = () => interopDefault(import('..\\pages\\topics.vue' /* webpackChunkName: "pages/topics" */))
const _f48c4b54 = () => interopDefault(import('..\\pages\\topics\\index.vue' /* webpackChunkName: "pages/topics/index" */))
const _365c13cc = () => interopDefault(import('..\\pages\\topics\\node\\feed.vue' /* webpackChunkName: "pages/topics/node/feed" */))
const _aba10ed8 = () => interopDefault(import('..\\pages\\topics\\node\\newest.vue' /* webpackChunkName: "pages/topics/node/newest" */))
const _4b53b87e = () => interopDefault(import('..\\pages\\topics\\node\\recommend.vue' /* webpackChunkName: "pages/topics/node/recommend" */))
const _43ca161e = () => interopDefault(import('..\\pages\\topics\\node\\_nodeId.vue' /* webpackChunkName: "pages/topics/node/_nodeId" */))
const _741baff4 = () => interopDefault(import('..\\pages\\topics\\tag\\_tagId.vue' /* webpackChunkName: "pages/topics/tag/_tagId" */))
const _439cb41a = () => interopDefault(import('..\\pages\\article\\create.vue' /* webpackChunkName: "pages/article/create" */))
const _e7c4aa5a = () => interopDefault(import('..\\pages\\topic\\create.vue' /* webpackChunkName: "pages/topic/create" */))
const _53862c58 = () => interopDefault(import('..\\pages\\user\\favorites.vue' /* webpackChunkName: "pages/user/favorites" */))
const _59ca3cdf = () => interopDefault(import('..\\pages\\user\\messages.vue' /* webpackChunkName: "pages/user/messages" */))
const _28a2e566 = () => interopDefault(import('..\\pages\\user\\profile.vue' /* webpackChunkName: "pages/user/profile" */))
const _104bb05c = () => interopDefault(import('..\\pages\\user\\profile\\index.vue' /* webpackChunkName: "pages/user/profile/index" */))
const _4ea237b7 = () => interopDefault(import('..\\pages\\user\\profile\\account.vue' /* webpackChunkName: "pages/user/profile/account" */))
const _58104018 = () => interopDefault(import('..\\pages\\user\\scores.vue' /* webpackChunkName: "pages/user/scores" */))
const _417d12f5 = () => interopDefault(import('..\\pages\\user\\signin.vue' /* webpackChunkName: "pages/user/signin" */))
const _5613696b = () => interopDefault(import('..\\pages\\user\\signup.vue' /* webpackChunkName: "pages/user/signup" */))
const _68d24cdc = () => interopDefault(import('..\\pages\\user\\email\\verify.vue' /* webpackChunkName: "pages/user/email/verify" */))
const _0dc1ea7b = () => interopDefault(import('..\\pages\\user\\github\\callback.vue' /* webpackChunkName: "pages/user/github/callback" */))
const _05130e81 = () => interopDefault(import('..\\pages\\user\\osc\\callback.vue' /* webpackChunkName: "pages/user/osc/callback" */))
const _cdae3910 = () => interopDefault(import('..\\pages\\user\\qq\\callback.vue' /* webpackChunkName: "pages/user/qq/callback" */))
const _7a9e64c2 = () => interopDefault(import('..\\pages\\article\\edit\\_id.vue' /* webpackChunkName: "pages/article/edit/_id" */))
const _536d4ba0 = () => interopDefault(import('..\\pages\\article\\redirect\\_id.vue' /* webpackChunkName: "pages/article/redirect/_id" */))
const _5b74712e = () => interopDefault(import('..\\pages\\topic\\edit\\_id.vue' /* webpackChunkName: "pages/topic/edit/_id" */))
const _3191768c = () => interopDefault(import('..\\pages\\article\\_id.vue' /* webpackChunkName: "pages/article/_id" */))
const _3f370fb0 = () => interopDefault(import('..\\pages\\link\\_id.vue' /* webpackChunkName: "pages/link/_id" */))
const _2302711d = () => interopDefault(import('..\\pages\\links\\_page.vue' /* webpackChunkName: "pages/links/_page" */))
const _69b64cdd = () => interopDefault(import('..\\pages\\tags\\_page.vue' /* webpackChunkName: "pages/tags/_page" */))
const _2885a273 = () => interopDefault(import('..\\pages\\topic\\_id.vue' /* webpackChunkName: "pages/topic/_id" */))
const _6e35e120 = () => interopDefault(import('..\\pages\\user\\_userId\\index.vue' /* webpackChunkName: "pages/user/_userId/index" */))
const _28c35bdf = () => interopDefault(import('..\\pages\\user\\_userId\\articles.vue' /* webpackChunkName: "pages/user/_userId/articles" */))
const _41823d7a = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _21ca62b5,
    name: "about"
  }, {
    path: "/articles",
    component: _2bf26945,
    children: [{
      path: "",
      component: _3d38e39d,
      name: "articles"
    }, {
      path: ":tagId",
      component: _3d6d2a1b,
      name: "articles-tagId"
    }]
  }, {
    path: "/redirect",
    component: _7b14a764,
    name: "redirect"
  }, {
    path: "/search",
    component: _84a7d95c,
    name: "search"
  }, {
    path: "/topics",
    component: _d7a2bea8,
    children: [{
      path: "",
      component: _f48c4b54,
      name: "topics"
    }, {
      path: "node/feed",
      component: _365c13cc,
      name: "topics-node-feed"
    }, {
      path: "node/newest",
      component: _aba10ed8,
      name: "topics-node-newest"
    }, {
      path: "node/recommend",
      component: _4b53b87e,
      name: "topics-node-recommend"
    }, {
      path: "node/:nodeId?",
      component: _43ca161e,
      name: "topics-node-nodeId"
    }, {
      path: "tag/:tagId?",
      component: _741baff4,
      name: "topics-tag-tagId"
    }]
  }, {
    path: "/article/create",
    component: _439cb41a,
    name: "article-create"
  }, {
    path: "/topic/create",
    component: _e7c4aa5a,
    name: "topic-create"
  }, {
    path: "/user/favorites",
    component: _53862c58,
    name: "user-favorites"
  }, {
    path: "/user/messages",
    component: _59ca3cdf,
    name: "user-messages"
  }, {
    path: "/user/profile",
    component: _28a2e566,
    children: [{
      path: "",
      component: _104bb05c,
      name: "user-profile"
    }, {
      path: "account",
      component: _4ea237b7,
      name: "user-profile-account"
    }]
  }, {
    path: "/user/scores",
    component: _58104018,
    name: "user-scores"
  }, {
    path: "/user/signin",
    component: _417d12f5,
    name: "user-signin"
  }, {
    path: "/user/signup",
    component: _5613696b,
    name: "user-signup"
  }, {
    path: "/user/email/verify",
    component: _68d24cdc,
    name: "user-email-verify"
  }, {
    path: "/user/github/callback",
    component: _0dc1ea7b,
    name: "user-github-callback"
  }, {
    path: "/user/osc/callback",
    component: _05130e81,
    name: "user-osc-callback"
  }, {
    path: "/user/qq/callback",
    component: _cdae3910,
    name: "user-qq-callback"
  }, {
    path: "/article/edit/:id?",
    component: _7a9e64c2,
    name: "article-edit-id"
  }, {
    path: "/article/redirect/:id?",
    component: _536d4ba0,
    name: "article-redirect-id"
  }, {
    path: "/topic/edit/:id?",
    component: _5b74712e,
    name: "topic-edit-id"
  }, {
    path: "/article/:id?",
    component: _3191768c,
    name: "article-id"
  }, {
    path: "/link/:id?",
    component: _3f370fb0,
    name: "link-id"
  }, {
    path: "/links/:page?",
    component: _2302711d,
    name: "links-page"
  }, {
    path: "/tags/:page?",
    component: _69b64cdd,
    name: "tags-page"
  }, {
    path: "/topic/:id?",
    component: _2885a273,
    name: "topic-id"
  }, {
    path: "/user/:userId",
    component: _6e35e120,
    name: "user-userId"
  }, {
    path: "/user/:userId?/articles",
    component: _28c35bdf,
    name: "user-userId-articles"
  }, {
    path: "/",
    component: _41823d7a,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
