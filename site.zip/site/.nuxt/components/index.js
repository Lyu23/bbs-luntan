export { default as ArticleList } from '../..\\components\\ArticleList.vue'
export { default as ArticleManageMenu } from '../..\\components\\ArticleManageMenu.vue'
export { default as Avatar } from '../..\\components\\Avatar.vue'
export { default as AvatarEdit } from '../..\\components\\AvatarEdit.vue'
export { default as CheckIn } from '../..\\components\\CheckIn.vue'
export { default as ColorMode } from '../..\\components\\ColorMode.vue'
export { default as Comment } from '../..\\components\\Comment.vue'
export { default as CommentInput } from '../..\\components\\CommentInput.vue'
export { default as CommentList } from '../..\\components\\CommentList.vue'
export { default as CreateTopicBtn } from '../..\\components\\CreateTopicBtn.vue'
export { default as FansWidget } from '../..\\components\\FansWidget.vue'
export { default as FollowBtn } from '../..\\components\\FollowBtn.vue'
export { default as FollowWidget } from '../..\\components\\FollowWidget.vue'
export { default as FriendLinks } from '../..\\components\\FriendLinks.vue'
export { default as GithubLogin } from '../..\\components\\GithubLogin.vue'
export { default as ImageUpload } from '../..\\components\\ImageUpload.vue'
export { default as LoadMore } from '../..\\components\\LoadMore.vue'
export { default as MarkdownEditor } from '../..\\components\\MarkdownEditor.vue'
export { default as MobileNav } from '../..\\components\\MobileNav.vue'
export { default as MobileNodes } from '../..\\components\\MobileNodes.vue'
export { default as MobileSidebar } from '../..\\components\\MobileSidebar.vue'
export { default as MsgNotice } from '../..\\components\\MsgNotice.vue'
export { default as MyCounts } from '../..\\components\\MyCounts.vue'
export { default as MyFooter } from '../..\\components\\MyFooter.vue'
export { default as MyNav } from '../..\\components\\MyNav.vue'
export { default as MyProfile } from '../..\\components\\MyProfile.vue'
export { default as News } from '../..\\components\\News.vue'
export { default as OscLogin } from '../..\\components\\OscLogin.vue'
export { default as Overlay } from '../..\\components\\Overlay.vue'
export { default as Pagination } from '../..\\components\\Pagination.vue'
export { default as PcNav } from '../..\\components\\PcNav.vue'
export { default as QqLogin } from '../..\\components\\QqLogin.vue'
export { default as ScoreRank } from '../..\\components\\ScoreRank.vue'
export { default as SearchInput } from '../..\\components\\SearchInput.vue'
export { default as SearchTopicList } from '../..\\components\\SearchTopicList.vue'
export { default as SearchTopicsNav } from '../..\\components\\SearchTopicsNav.vue'
export { default as SimpleEditor } from '../..\\components\\SimpleEditor.vue'
export { default as SiteNotice } from '../..\\components\\SiteNotice.vue'
export { default as StickyTopics } from '../..\\components\\StickyTopics.vue'
export { default as SubCommentList } from '../..\\components\\SubCommentList.vue'
export { default as TagInput } from '../..\\components\\TagInput.vue'
export { default as TextEditor } from '../..\\components\\TextEditor.vue'
export { default as TopicList } from '../..\\components\\TopicList.vue'
export { default as TopicManageMenu } from '../..\\components\\TopicManageMenu.vue'
export { default as TopicsNav } from '../..\\components\\TopicsNav.vue'
export { default as UserCenterSidebar } from '../..\\components\\UserCenterSidebar.vue'
export { default as UserFollowList } from '../..\\components\\UserFollowList.vue'
export { default as UserInfo } from '../..\\components\\UserInfo.vue'
export { default as UserProfile } from '../..\\components\\UserProfile.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
