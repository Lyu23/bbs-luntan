const middleware = {}

middleware['authenticated'] = require('..\\middleware\\authenticated.js')
middleware['authenticated'] = middleware['authenticated'].default || middleware['authenticated']

middleware['resetEnv'] = require('..\\middleware\\resetEnv.js')
middleware['resetEnv'] = middleware['resetEnv'].default || middleware['resetEnv']

export default middleware
